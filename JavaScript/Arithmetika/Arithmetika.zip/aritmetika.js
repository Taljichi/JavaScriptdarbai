// let kubas = Math.pow(2, 3);


// console.log(kubas);

// let x = 5;
// let y = 4;
// let z = 7;

// console.log(x + y + z);
// console.log(x*y*z);

// let x = 10;
// let y = 4;

// let z = x+y;
// let c = x-y;

// console.log(z*c);
// console.log(z/c);

// let x = 7;
// let y = 4;
// let z = 9;
// let c = 1;

// let f = (x+y+z+c)/4;

// console.log(f);

// let x = 6;
// let y = 3;

// console.log(x, '+', y, '=',x+y);
// console.log(x, '-', y, '=',x-y);
// console.log(x, '/', y, '=',x/y);
// console.log(x, '*', y, '=',x*y);

// console.log(`${x} + ${y} = ${x+y}`);
// console.log(`${x} - ${y} = ${x+y}`);
// console.log(`${x} / ${y} = ${x+y}`);
// console.log(`${x} * ${y} = ${x+y}`);


// console.log(-1 + 4 * 6);
// console.log((35+5) % 7);
// console.log(14+ -4 * 6 / 12);
// console.log(2 + 15 / 6 * 1 - 7 % 2);


// console.log(`${5} * ${1} = ${5}`);
// console.log(`${5} * ${2} = ${10}`);
// console.log(`${5} * ${3} = ${15}`);
// console.log(`${5} * ${4} = ${20}`);
// console.log(`${5} * ${5} = ${25}`);
// console.log(`${5} * ${6} = ${30}`);
// console.log(`${5} * ${7} = ${35}`);
// console.log(`${5} * ${8} = ${40}`);
// console.log(`${5} * ${9} = ${45}`);
// console.log(`${5} * ${10} = ${50}`);



// let Skaicius = 73;
// let pirmas = Math.floor(Skaicius / 10);
// let antras = Skaicius % 10;
// let suma = pirmas + antras;
// console.log("Skaitmenų suma: " + suma);

// myNumber = 34;

// console.log(
//   `Skaicius: ${myNumber}, skaitmenu suma: ${
//     Math.floor(myNumber / 10) + (myNumber % 10)
//   }`
// );