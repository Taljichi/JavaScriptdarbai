// const procentai = 2.1;
// console.log(procentai);

// procentai = 1.8;
// console.log(procentai);


// let marke = 'Audi';
// let modelis = 'A5';
// let metai = 2005;

// console.log(marke +' ' + modelis + ' Buvo pagaminta ' + metai + ' metais');

// console.log(marke, modelis, 'buvo pagaminta', metai, 'metais');

// console.log('${marke} ${modelis} buvo pagaminta ${metai} metais');



// let vardas = 'Greta';
// let amzius = 22;
// let studente = true;
// let teises = undefined;
// let augintinis = null;

// console.log(typeof vardas);
// console.log(typeof amzius);
// console.log(typeof studente);
// console.log(typeof teises);
// console.log(typeof augintinis);

// console.log('vardas', typeof vardas);
// console.log('amzius', typeof amzius);
// console.log('studente', typeof studente);
// console.log('teises', typeof teises);
// console.log('augintinis', typeof augintinis);


// let vardas = 'Greta';
// let amzius = 22;

// console.log('vardas', vardas, typeof vardas);
// console.log('amzius', amzius, typeof amzius);

// vardas = 3;
// amzius = 'abc';

// console.log('vardas', vardas, typeof vardas);
// console.log('amzius', amzius, typeof amzius);


// console.log('per\nkelias\neilutes');

// let tekstas = 'per 
// kelias 
// eilutes';

// console.log(tekstas);



// console.log('Vardas\nPavarde\nAmzius\nUgis\nSvoris\nAukstoji mokykla\nAkademines grupes kodas\nKursas\nStudiju programos pavadinimas\nAtsiskaitytu kreditu skaicius');

// const pavadinimas = 'Pavadinimas';
// const valstybe = 'Valstybe';
// const apskritis = 'Apskritis';
// const data = 'Ikurimo data';
// const meras = 'Meras';
// const plotas = 'Plotas';
// const gyventojai = 'Gyventoju skaicius';

// console.log(pavadinimas + '\n', valstybe + '\n', apskritis + '\n', data + '\n', meras + '\n', plotas + '\n', gyventojai);

// const vardas = 'Marius';

// console.log('Mano vardas', vardas);

// let grupe = 'ifzm-6';
// let vidurkis = 8;

// console.log('akademine grupe: ', grupe);
// console.log('Vidurkis: ', vidurkis);

// let zodis = 'Zodis';

// console.log(zodis + zodis + zodis + zodis + zodis);

// let pavadinimas = 'Suo';
// let amzius = '(2 m.)';
// let kailis = 'ruda kailio spalva';
// let svoris = 1.4;

// console.log('Gyvunas -', pavadinimas, amzius, 'turi', kailis, 'ir sveria', svoris, 'kg.' )

// let skaicius = 25;
// let kartai = 5;

// let rezultatas ="";

// for (let i = 0; i < kartai; i++) { 
//     rezultatas += skaicius;
// }

// console.log(rezultatas);

// let skaicius = 25;

// console.log(skaicius, skaicius, skaicius, skaicius, skaicius);

// let kva = '*';

// console.log(kva + kva + kva + kva)
// console.log(kva, '', kva)
// console.log(kva + kva + kva + kva)

// let skaicius = 25;

// console.log(`${skaicius}${skaicius}${skaicius}${skaicius}${skaicius}`);

// let skaicius = '33';
// console.log('išvedimas -' , skaicius + skaicius + skaicius + skaicius +skaicius) 